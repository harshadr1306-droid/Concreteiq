/**
 * ConcreteIQ — Netlify Serverless Function: /api/analyse-image
 * Proxies image analysis requests to Claude Vision API server-side.
 *
 * Set ANTHROPIC_API_KEY in Netlify → Site Settings → Environment Variables
 */

export default async function handler(req, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (req.method === 'OPTIONS') {
    return new Response('', { status: 204, headers });
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return new Response(
      JSON.stringify({ error: 'ANTHROPIC_API_KEY not configured in Netlify environment variables.' }),
      { status: 500, headers }
    );
  }

  let body;
  try {
    body = await req.json();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), { status: 400, headers });
  }

  const { base64, mime = 'image/jpeg', prompt } = body;
  if (!base64) {
    return new Response(JSON.stringify({ error: 'Missing base64 image data' }), { status: 400, headers });
  }

  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'anthropic-version': '2023-06-01',
      'x-api-key': apiKey,
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 200,
      system: prompt,
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: mime, data: base64 } },
          { type: 'text', text: 'Classify this image. Is it construction aggregate? Respond with JSON only.' }
        ]
      }],
    }),
  });

  const data = await resp.json();

  if (!resp.ok) {
    return new Response(JSON.stringify({ error: data?.error?.message || 'API error' }), {
      status: resp.status,
      headers,
    });
  }

  // Extract and parse JSON from Claude's response
  const textBlock = data.content?.find(c => c.type === 'text');
  if (!textBlock) {
    return new Response(JSON.stringify({ error: 'No text in response' }), { status: 500, headers });
  }

  let clean = textBlock.text.trim().replace(/^```json\s*|^```\s*|```\s*$/gm, '').trim();
  const jm = clean.match(/\{[\s\S]*\}/);
  if (jm) clean = jm[0];

  try {
    const result = JSON.parse(clean);
    return new Response(JSON.stringify(result), { status: 200, headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Failed to parse AI response', raw: clean.slice(0, 200) }), {
      status: 500,
      headers,
    });
  }
}
