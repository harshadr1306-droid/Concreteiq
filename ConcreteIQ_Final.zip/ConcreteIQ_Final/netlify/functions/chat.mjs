/**
 * ConcreteIQ — Netlify Serverless Function: /api/chat
 * Proxies AI chat requests to Anthropic API server-side
 * so the API key is never exposed client-side.
 *
 * Set ANTHROPIC_API_KEY in Netlify → Site Settings → Environment Variables
 */

export default async function handler(req, context) {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (req.method === 'OPTIONS') {
    return new Response('', { status: 204, headers });
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return new Response(
      JSON.stringify({ error: 'ANTHROPIC_API_KEY not configured. Add it in Netlify → Site Settings → Environment Variables.' }),
      { status: 500, headers }
    );
  }

  let body;
  try {
    body = await req.json();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), { status: 400, headers });
  }

  // Forward to Anthropic
  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'anthropic-version': '2023-06-01',
      'x-api-key': apiKey,
    },
    body: JSON.stringify({
      model: body.model || 'claude-sonnet-4-20250514',
      max_tokens: Math.min(body.max_tokens || 1000, 2000),
      system: body.system,
      messages: body.messages,
    }),
  });

  const data = await resp.json();

  if (!resp.ok) {
    return new Response(JSON.stringify({ error: data?.error?.message || 'Anthropic API error' }), {
      status: resp.status,
      headers,
    });
  }

  return new Response(JSON.stringify(data), { status: 200, headers });
}
